"""Constants for Mail and Packages."""

from __future__ import annotations

from typing import Final

from homeassistant.components.binary_sensor import BinarySensorDeviceClass
from homeassistant.components.sensor import SensorDeviceClass, SensorEntityDescription
from homeassistant.helpers.entity import EntityCategory

from .entity import MailandPackagesBinarySensorEntityDescription

DOMAIN = "mail_and_packages"
DOMAIN_DATA = f"{DOMAIN}_data"
VERSION = "0.0.0-dev"  # Now updated by release workflow
ISSUE_URL = "http://github.com/moralmunky/Home-Assistant-Mail-And-Packages"
PLATFORM = "sensor"
PLATFORMS = ["binary_sensor", "camera", "sensor"]
DATA = "data"
COORDINATOR = "coordinator_mail"
OVERLAY = ["overlay.png", "vignette.png", "white.png"]
SERVICE_UPDATE_FILE_PATH = "update_file_path"
CAMERA = "cameras"
CONFIG_VER = 19

# Attributes
ATTR_AMAZON_IMAGE = "amazon_image"
ATTR_COUNT = "count"
ATTR_CODE = "code"
ATTR_GRID_IMAGE_NAME = "grid_image"
ATTR_ORDER = "order"
ATTR_TRACKING = "tracking"
ATTR_TRACKING_NUM = "tracking_#"
ATTR_IMAGE = "image"
ATTR_IMAGE_PATH = "image_path"
ATTR_SERVER = "server"
ATTR_IMAGE_NAME = "image_name"
ATTR_EMAIL = "email"
ATTR_SUBJECT = "subject"
ATTR_BODY = "body"
ATTR_BODY_COUNT = "body_count"
ATTR_PATTERN = "pattern"
ATTR_USPS_MAIL = "usps_mail"
ATTR_UPS_IMAGE = "ups_image"
ATTR_WALMART_IMAGE = "walmart_image"
ATTR_FEDEX_IMAGE = "fedex_image"
ATTR_GENERIC_IMAGE = "generic_image"
ATTR_USPS_IMAGE = "usps_image"

# Configuration Properties
CONF_ALLOW_EXTERNAL = "allow_external"
CONF_CAMERA_NAME = "camera_name"
CONF_CUSTOM_IMG = "custom_img"
CONF_CUSTOM_IMG_FILE = "custom_img_file"
CONF_AMAZON_CUSTOM_IMG = "amazon_custom_img"
CONF_AMAZON_CUSTOM_IMG_FILE = "amazon_custom_img_file"
CONF_UPS_CUSTOM_IMG = "ups_custom_img"
CONF_UPS_CUSTOM_IMG_FILE = "ups_custom_img_file"
CONF_WALMART_CUSTOM_IMG = "walmart_custom_img"
CONF_WALMART_CUSTOM_IMG_FILE = "walmart_custom_img_file"
CONF_FEDEX_CUSTOM_IMG = "fedex_custom_img"
CONF_FEDEX_CUSTOM_IMG_FILE = "fedex_custom_img_file"
CONF_GENERIC_CUSTOM_IMG = "generic_custom_img"
CONF_GENERIC_CUSTOM_IMG_FILE = "generic_custom_img_file"
CONF_STORAGE = "storage"
CONF_FOLDER = "folder"
CONF_PATH = "image_path"
CONF_DURATION = "gif_duration"
CONF_SCAN_INTERVAL = "scan_interval"
CONF_IMAGE_SECURITY = "image_security"
CONF_IMAP_TIMEOUT = "imap_timeout"
CONF_GENERATE_GRID = "generate_grid"
CONF_GENERATE_MP4 = "generate_mp4"
CONF_AMAZON_FWDS = "amazon_fwds"
CONF_AMAZON_DAYS = "amazon_days"
CONF_VERIFY_SSL = "verify_ssl"
CONF_IMAP_SECURITY = "imap_security"
CONF_AMAZON_DOMAIN = "amazon_domain"
CONF_ALLOW_FORWARDED_EMAILS = "allow_forwarded_emails"
CONF_FORWARDED_EMAILS = "forwarded_emails"
CONF_FORWARDING_HEADER = "forwarding_header"
CONF_CUSTOM_DAYS = "custom_days"
CONF_17TRACK_API_KEY = "seventeen_track_api_key"
CONF_AMAZON_ENABLED = "amazon_enabled"
CONF_DHL_BRIEF_ENABLED = "dhl_brief_enabled"
CONF_DHL_BRIEF_TOKENS = "dhl_brief_tokens"

# Defaults
DEFAULT_CAMERA_NAME = "Mail USPS Camera"
DEFAULT_NAME = "Mail And Packages"
DEFAULT_PORT = "993"
DEFAULT_FOLDER = "INBOX"
DEFAULT_PATH = "custom_components/mail_and_packages/images/"
DEFAULT_IMAGE_SECURITY = True
DEFAULT_IMAP_TIMEOUT = 60
DEFAULT_GIF_DURATION = 5
DEFAULT_SCAN_INTERVAL = 30
DEFAULT_CUSTOM_DAYS = 3
MAX_TRACKING_AGE_DAYS = 14
DEFAULT_GIF_FILE_NAME = "mail_today.gif"
DEFAULT_AMAZON_FWDS = "(none)"
DEFAULT_ALLOW_EXTERNAL = False
DEFAULT_CUSTOM_IMG = False
DEFAULT_CUSTOM_IMG_FILE = "custom_components/mail_and_packages/mail_none.gif"
DEFAULT_AMAZON_CUSTOM_IMG = False
DEFAULT_AMAZON_CUSTOM_IMG_FILE = (
    "custom_components/mail_and_packages/no_deliveries_amazon.jpg"
)
DEFAULT_UPS_CUSTOM_IMG = False
DEFAULT_UPS_CUSTOM_IMG_FILE = (
    "custom_components/mail_and_packages/no_deliveries_ups.jpg"
)
DEFAULT_WALMART_CUSTOM_IMG = False
DEFAULT_WALMART_CUSTOM_IMG_FILE = (
    "custom_components/mail_and_packages/no_deliveries_walmart.jpg"
)
DEFAULT_FEDEX_CUSTOM_IMG = False
DEFAULT_FEDEX_CUSTOM_IMG_FILE = (
    "custom_components/mail_and_packages/no_deliveries_fedex.jpg"
)
DEFAULT_GENERIC_CUSTOM_IMG = False
DEFAULT_GENERIC_CUSTOM_IMG_FILE = (
    "custom_components/mail_and_packages/no_deliveries_generic.jpg"
)
DEFAULT_AMAZON_DAYS = 3
DEFAULT_AMAZON_DOMAIN = "amazon.com"
DEFAULT_STORAGE = "custom_components/mail_and_packages/images/"

DEFAULT_ALLOW_FORWARDED_EMAILS = False
DEFAULT_FORWARDED_EMAILS = "(none)"
DEFAULT_FORWARDING_HEADER = "(none)"

# Amazon
AMAZON_DOMAINS = [
    "amazon.com",
    "amazon.ca",
    "amazon.co.uk",
    "amazon.in",
    "amazon.de",
    "amazon.it",
    "amazon.com.au",
    "amazon.pl",
    "amazon.es",
    "amazon.fr",
    "amazon.ae",
    "amazon.nl",
]
AMAZON_DELIVERED_SUBJECT = [
    "Delivered: ",
    "Your Amazon order has arrived!",
    "Consegna effettuata:",
    "Dostarczono:",
    "Geliefert:",
    "Livré",
    "Entregado:",
    "Bezorgd:",
    "Livraison : Votre",
    "Zugestellt:",
]
AMAZON_SHIPMENT_TRACKING = [
    "auto-confirm",
    "shipment-tracking",
    "order-update",
    "conferma-spedizione",
    "confirmar-envio",
    "versandbestaetigung",
    "confirmation-commande",
    "verzending-volgen",
    "update-bestelling",
]
AMAZON_SHIPMENT_SUBJECT = [
    "Shipped:",
    "Enviado:",
    "Out for delivery:",
]
AMAZON_ORDERED_SUBJECT = ["Ordered:", "Pedido efetuado:"]
AMAZON_EMAIL = [
    "order-update@",
    "update-bestelling@",
    "versandbestaetigung@",
    "verzending-volgen@",
    "auto-bevestiging@",
]
AMAZON_PACKAGES = "amazon_packages"
AMAZON_ORDER = "amazon_order"
AMAZON_DELIVERED = "amazon_delivered"
AMAZON_IMG_LIST = [
    "us-prod-temp.s3.amazonaws.com",
    "gb-prod-temp.s3.eu-west-1.amazonaws.com",
]
AMAZON_IMG_PATTERN = (
    "(https://)([\\w_-]+(?:(?:\\.[\\w_-]+)+))([\\w.,@?^=%&:/~+#-;]*[\\w@?^=%&/~+#-;])?"
)
AMAZON_HUB = "amazon_hub"
AMAZON_HUB_CODE = "amazon_hub_code"
AMAZON_HUB_EMAIL = [
    "thehub@amazon.com",
    "order-update@amazon.com",
    "amazonlockers@amazon.com",
    "versandbestaetigung@amazon.de",
]
AMAZON_HUB_SUBJECT = ["ready for pickup from Amazon Hub Locker"]
AMAZON_HUB_SUBJECT_SEARCH = "(a package to pick up)(.*)(\\d{6})"
AMAZON_HUB_BODY = "(Your pickup code is <b>)(\\d{6})"
AMAZON_TIME_PATTERN = [
    "will arrive:",
    "estimated delivery date is:",
    "guaranteed delivery date is:",
    "Arriving:",
    "Arriverà:",
    "arriving:",
    "Arriving ",
    "Dostawa:",
    "Entrega:",
    "A chegar:",
    "Arrivée :",
    "Chega ",
    "Verwachte bezorgdatum:",
    "Votre date de livraison prévue est :",
]
AMAZON_TIME_PATTERN_END = [
    "Previously expected:",
    "This contains",
    "Track your",
    "Per tracciare il tuo pacco",
    "View or manage order",
    "Acompanhar",
    "Seguimiento",
    "Verfolge deine(n) Artikel",
    "Lieferung verfolgen",
    "Ihr Paket verfolgen",
    "Suivre",
    "Volg je pakket",
    "Je pakket volgen",
]
AMAZON_TIME_PATTERN_REGEX = [
    "Arriving (\\w+ \\d+) - (\\w+ \\d+)",
    "Arriving (\\w+ \\d+)",
    "Arriving (\\w+ ?\\d*)",
    "Arriving (\\w+)",
    "Zustellung (\\w+ \\d+) - (\\w+ \\d+)",
    "Zustellung (\\w+ \\d+)",
    "Zustellung (\\w+ \\d*)",
    "Arriverà (\\w+ \\d+) - (\\w+ \\d+)",
    "Arriverà (\\w+ \\d+)",
    "Arriverà (\\w+ \\d*)",
    "Arrivée (\\w+ \\d+) - (\\w+ \\d+)",
    "Arrivée (\\w+ \\d+)",
    "Arrivée (\\w+ \\d*)",
    "Chega ((\\w+(-\\w+)?))",
    "Arriving (tomorrow)",
    "Arriving (today)",
    "Wordt bezorgd op (\\w+ \\d+ \\w+)",
    "Wordt bezorgd op (\\w+ \\d+)",
    "Wordt (vandaag) bezorgd",
]
AMAZON_EXCEPTION_SUBJECT = "Delivery update:"
AMAZON_EXCEPTION_BODY = "running late"
AMAZON_EXCEPTION = "amazon_exception"
AMAZON_EXCEPTION_ORDER = "amazon_exception_order"
AMAZON_PATTERN = "[0-9]{3}-[0-9]{7}-[0-9]{7}"
AMAZON_LANGS = [
    "it_IT",
    "it_IT.UTF-8",
    "pl_PL",
    "pl_PL.UTF-8",
    "de_DE",
    "de_DE.UTF-8",
    "es_ES",
    "es_ES.UTF-8",
    "pt_PT",
    "pt_PT.UTF-8",
    "pt_BR",
    "pt_BR.UTF-8",
    "fr_CA",
    "fr_CA.UTF-8",
    "",
]
AMAZON_OTP = "amazon_otp"
AMAZON_OTP_CODE = "amazon_otp_code"
AMAZON_OTP_REGEX = "(\n)(\\d{6})(\n)"
AMAZON_OTP_SUBJECT = "A one-time password is required for your Amazon delivery"

AMAZON_DELIEVERED_BY_OTHERS_SEARCH_TEXT = ["AMAZON"]

# Sensor Data
SENSOR_DATA = {
    # USPS
    "usps_delivered": {
        "email": ["auto-reply@usps.com", "auto-reply@tracking.usps.com"],
        "subject": ["Item Delivered"],
    },
    "usps_delivering": {
        "email": ["auto-reply@usps.com", "auto-reply@tracking.usps.com"],
        "subject": ["Expected Delivery on", "Out for Delivery"],
        "body": ["Your item is out for delivery"],
    },
    "usps_exception": {
        "email": ["auto-reply@usps.com", "auto-reply@tracking.usps.com"],
        "subject": ["Delivery Exception"],
    },
    "usps_packages": {
        "email": ["auto-reply@usps.com", "auto-reply@tracking.usps.com"],
        "subject": ["Expected Delivery by"],
    },
    "usps_tracking": {"pattern": ["9[2345]\\d{15,26}"]},
    "usps_mail": {
        "email": [
            "USPSInformedDelivery@usps.gov",
            "USPSInformeddelivery@email.informeddelivery.usps.com",
            "USPSInformeddelivery@informeddelivery.usps.com",
            "USPS Informed Delivery",
        ],
        "subject": ["Your Daily Digest"],
    },
    "usps_mail_delivered": {
        "email": [
            "USPSInformedDelivery@usps.gov",
            "USPSInformeddelivery@email.informeddelivery.usps.com",
            "USPSInformeddelivery@informeddelivery.usps.com",
            "USPS Informed Delivery",
        ],
        "subject": ["Your Mail Was Delivered"],
    },
    # UPS
    "ups_delivered": {
        "email": ["mcinfo@ups.com", "pkginfo@ups.com"],
        "subject": [
            "Your UPS Package was delivered",
            "Your UPS Packages were delivered",
            "Your UPS Parcel was delivered",
            "Your UPS Parcels were delivered",
            "Votre colis UPS a été livré",
            "Paket wurde zugestellt",
        ],
    },
    "ups_delivering": {
        "email": ["mcinfo@ups.com", "pkginfo@ups.com"],
        "subject": [
            "UPS Update: Package Scheduled for Delivery Today",
            "UPS Update: Follow Your Delivery on a Live Map",
            "UPS Pre-Arrival: Your Driver is Arriving Soon! Follow on a Live Map",
            "UPS Update: Parcel Scheduled for Delivery Today",
            "Mise à jour UPS : Livraison du colis prévue demain",
            "Mise à jour UPS : Livraison du colis prévue aujourd'hui",
        ],
    },
    "ups_exception": {
        "email": ["mcinfo@ups.com"],
        "subject": ["UPS Update: New Scheduled Delivery Date"],
    },
    "ups_packages": {
        "email": ["mcinfo@ups.com", "pkginfo@ups.com"],
        "subject": ["UPS Ship Notification"],
    },
    "ups_tracking": {"pattern": ["1Z?[0-9A-Z]{16}"]},
    # FedEx
    "fedex_delivered": {
        "email": [
            "TrackingUpdates@fedex.com",
            "fedexcanada@fedex.com",
            "noreply@fedex.com",
        ],
        "subject": [
            "Your package has been delivered",
            "Your packages have been delivered",
            "Your shipment was delivered",
        ],
    },
    "fedex_delivering": {
        "email": [
            "TrackingUpdates@fedex.com",
            "fedexcanada@fedex.com",
            "noreply@fedex.com",
        ],
        "subject": [
            "Delivery scheduled for today",
            "Your package is scheduled for delivery today",
            "Your package is now out for delivery",
            "Your shipment is out for delivery today",
            "out for delivery today",
            "Ihre Sendung wird voraussichtlich heute zugestellt",
        ],
    },
    "fedex_packages": {
        "email": [
            "TrackingUpdates@fedex.com",
            "fedexcanada@fedex.com",
            "noreply@fedex.com",
        ],
        "subject": ["Your shipment is on the way"],
    },
    "fedex_exception": {
        "email": [
            "TrackingUpdates@fedex.com",
            "fedexcanada@fedex.com",
            "noreply@fedex.com",
        ],
        # Subject confirmed against a real FedEx delivery-exception
        # notification (From: trackingupdates@fedex.com, Subject:
        # "FedEx Delivery Exception"). IMAP SUBJECT search is a
        # case-insensitive substring match, mirroring usps_exception's
        # "Delivery Exception" fragment.
        "subject": ["FedEx Delivery Exception"],
    },
    "fedex_tracking": {"pattern": ["\\d{12,20}"]},
    # Canada Post
    "capost_delivered": {
        "email": [
            "donotreply@canadapost.postescanada.ca",
            "donotreply-nepasrepondre@notifications.canadapost-postescanada.ca",
        ],
        "subject": [
            "Delivery Notification",
        ],
    },
    "capost_delivering": {
        "email": [
            "donotreply-nepasrepondre@notifications.canadapost-postescanada.ca",
        ],
        "subject": [
            "Your parcel is out for delivery",
        ],
    },
    "capost_packages": {},
    "capost_tracking": {"pattern": ["\\d{16}"]},
    "capost_mail": {
        "email": ["donotreply-nepasrepondre@communications.canadapost-postescanada.ca"],
        "subject": ["You have mail on the way"],
        "body": ["\\sYou have (\\d) piece|pieces of mail\\s"],
        "body_count": True,
    },
    # DHL
    "dhl_delivered": {
        "email": [
            "donotreply_odd@dhl.com",
            "NoReply.ODD@dhl.com",
            "noreply@dhl.de",
            "pl.no.reply@dhl.com",
            "support@dhl.com",
            "noreply@dhlecommerce.nl",
            "noreply@dhl.nl",
        ],
        "subject": [
            "DHL On Demand Delivery",
            "Powiadomienie o przesyłce",
            "wurde zugestellt",
            "DHL Shipment Notification",
            "liegt am gewünschten Ablageort",
            "succesvol bezorgd",
            "is bezorgd",
        ],
        "body": [
            "has been delivered",
            "została doręczona",
            "ist angekommen",
            'Notification for shipment event group "Delivered',
            " - Delivered - ",
            "succesvol bezorgd",
            "is bezorgd",
            "pakket is afgeleverd",
        ],
    },
    "dhl_delivering": {
        "email": [
            "donotreply_odd@dhl.com",
            "NoReply.ODD@dhl.com",
            "noreply@dhl.de",
            "pl.no.reply@dhl.com",
            "support@dhl.com",
            "noreply@dhlecommerce.nl",
            "noreply@dhl.nl",
        ],
        "subject": [
            "DHL On Demand Delivery",
            "Paket kommt heute",
            "kommt heute",
            "wird gleich zugestellt",
            "Powiadomienie o przesyłce",
            "DHL Shipment Notification",
            "ist unterwegs",
            "Jetzt Live verfolgen",
            "vanavond voor de deur",
            "vandaag voor de deur",
            "pakket onderweg",
            "bezorging vandaag",
            "staan vandaag voor de deur",
            "staan vanavond voor de deur",
            "komen we bij je langs",
        ],
        "body": [
            "scheduled for delivery TODAY",
            "zostanie dziś do Państwa doręczona",
            "wird Ihnen heute",
            "heute zwischen",
            " - Shipment is out with courier for delivery - ",
            "Shipment is scheduled for delivery",
            "voraussichtlich innerhalb",
            "staan vandaag voor de deur",
            "staan vanavond voor de deur",
            "wordt vandaag bezorgd",
            "bezorger onderweg",
            "komen we bij je langs",
        ],
    },
    "dhl_packages": {},
    "dhl_tracking": {
        "pattern": [
            "(?:JJD\\d{18}|JVGL\\d{20}|MDP[A-Z0-9]{5,15}|00\\d{18}|(?<![0-9])\\d{10,11}(?![0-9]))",
        ],
    },
    # Hermes.co.uk
    "hermes_delivered": {
        "email": ["donotreply@myhermes.co.uk"],
        "subject": ["Hermes has successfully delivered your"],
    },
    "hermes_delivering": {
        "email": [
            "donotreply@myhermes.co.uk",
            "noreply@paketankuendigung.myhermes.de",
        ],
        "subject": [
            "parcel is now with your local Hermes courier",
            "Ihre Hermes Sendung",
            "Deine Hermes Sendung",
        ],
        "body": [
            "Voraussichtliche Zustellung",
        ],
    },
    "hermes_packages": {},
    "hermes_tracking": {"pattern": ["\\d{11,20}"]},
    # Royal Mail
    "royal_delivered": {
        "email": ["no-reply@royalmail.com"],
        "subject": ["has been delivered"],
    },
    "royal_delivering": {
        "email": ["no-reply@royalmail.com"],
        "subject": ["is on its way", "to be delivered today"],
    },
    "royal_packages": {},
    "royal_tracking": {"pattern": ["[A-Za-z]{2}[0-9]{9}GB"]},
    # Poczta Polska SA
    "poczta_polska_delivered": {},
    "poczta_polska_delivering": {
        "email": ["informacja@poczta-polska.pl", "powiadomienia@allegromail.pl"],
        "subject": ["Poczta Polska S.A. eINFO"],
    },
    "poczta_polska_packages": {},
    "poczta_polska_tracking": {
        # http://emonitoring.poczta-polska.pl/?numer=00359007738913296666
        "pattern": ["\\d{20}"],
    },
    # InPost.pl
    "inpost_pl_delivered": {
        "email": [
            "powiadomienia@inpost.pl",
            "info@paczkomaty.pl",
            "powiadomienia@allegromail.pl",
        ],
        "subject": [
            "InPost - Potwierdzenie odbioru",
            "InPost - Paczka umieszczona w Paczkomacie",
        ],
    },
    "inpost_pl_delivering": {
        "email": [
            "powiadomienia@inpost.pl",
            "info@paczkomaty.pl",
            "powiadomienia@allegromail.pl",
        ],
        "subject": [
            "Kurier InPost: Twoja paczka jest w drodze",
            "prawie u Ciebie",
        ],
    },
    "inpost_pl_packages": {},
    "inpost_pl_tracking": {
        # https://inpost.pl/sledzenie-przesylek?number=520113017830399002575123
        "pattern": ["\\d{24}"],
    },
    # DPD Poland
    "dpd_com_pl_delivered": {
        "email": [
            "KurierDPD0@dpd.com.pl",
            "KurierDPD1@dpd.com.pl",
            "KurierDPD2@dpd.com.pl",
            "KurierDPD3@dpd.com.pl",
            "KurierDPD4@dpd.com.pl",
            "KurierDPD5@dpd.com.pl",
            "KurierDPD6@dpd.com.pl",
            "KurierDPD7@dpd.com.pl",
            "KurierDPD8@dpd.com.pl",
            "KurierDPD9@dpd.com.pl",
            "KurierDPD10@dpd.com.pl",
            "powiadomienia@allegromail.pl",
        ],
        "subject": ["została doręczona"],
    },
    "dpd_com_pl_delivering": {
        "email": [
            "KurierDPD0@dpd.com.pl",
            "KurierDPD1@dpd.com.pl",
            "KurierDPD2@dpd.com.pl",
            "KurierDPD3@dpd.com.pl",
            "KurierDPD4@dpd.com.pl",
            "KurierDPD5@dpd.com.pl",
            "KurierDPD6@dpd.com.pl",
            "KurierDPD7@dpd.com.pl",
            "KurierDPD8@dpd.com.pl",
            "KurierDPD9@dpd.com.pl",
            "KurierDPD10@dpd.com.pl",
            "powiadomienia@allegromail.pl",
        ],
        "subject": [
            "Bezpieczne doręczenie",
            "przesyłka została nadana",
        ],
        "body": ["Dziś doręczamy", "DPD Polska"],
    },
    "dpd_com_pl_packages": {},
    "dpd_com_pl_tracking": {
        # https://tracktrace.dpd.com.pl/parcelDetails?p1=13490015284111
        "pattern": [
            "\\d{13}[A-Z0-9]{1,2}",
        ],
    },
    # DPD
    "dpd_delivered": {
        "email": [
            "noreply@service.dpd.de",
        ],
        "subject": [
            "Ihr Paket ist da!",
            "Die Abstellung Ihres DPD Pakets ist erfolgt",
        ],
    },
    "dpd_delivering": {
        "email": [
            "noreply@service.dpd.de",
        ],
        "subject": [
            "Bald ist ihr DPD Paket da",
            "kommt Ihr DPD Paket",
        ],
        "body": [
            "Paketnummer",
        ],
    },
    "dpd_packages": {},
    "dpd_tracking": {
        # https://tracktrace.dpd.com.pl/parcelDetails?p1=13490015284111
        "pattern": [
            "\\d{11,20}",
        ],
    },
    # DPD France
    "dpd_fr_delivered": {
        "email": [
            "noreply@dpd.fr",
            "notification@dpd.fr",
            "no-reply@dpd.fr",
        ],
        "subject": [
            "Votre colis a été livré",
            "Votre colis est livré",
            "livré avec succès",
            "remis à",
        ],
    },
    "dpd_fr_delivering": {
        "email": [
            "noreply@dpd.fr",
            "notification@dpd.fr",
            "no-reply@dpd.fr",
        ],
        "subject": [
            "Votre colis est en cours de livraison",
            "sera livré aujourd'hui",
            "livraison prévue aujourd'hui",
            "en route vers vous",
        ],
        "body": [
            "numéro de colis",
            "votre livreur",
        ],
    },
    "dpd_fr_packages": {},
    "dpd_fr_tracking": {
        # https://www.dpd.fr/tracking
        "pattern": [
            "\\d{14}",
        ],
    },
    # DPD UK
    "dpd_uk_delivered": {
        "email": [
            "tracking@dpd.co.uk",
            "notification@dpd.co.uk",
            "noreply@dpd.co.uk",
        ],
        "subject": [
            "Your DPD parcel has been delivered",
            "has been delivered",
            "delivered to your address",
        ],
    },
    "dpd_uk_delivering": {
        "email": [
            "tracking@dpd.co.uk",
            "notification@dpd.co.uk",
            "noreply@dpd.co.uk",
        ],
        "subject": [
            "Your DPD parcel is on its way",
            "out for delivery",
            "arriving today",
            "delivery expected today",
        ],
        "body": [
            "parcel number",
            "your driver",
            "estimated delivery",
        ],
    },
    "dpd_uk_packages": {},
    "dpd_uk_tracking": {
        # https://www.dpd.co.uk/apps/tracking/
        "pattern": [
            "\\d{14}",
        ],
    },
    # GLS
    "gls_delivered": {
        "email": [
            "noreply@gls-group.eu",
            "powiadomienia@allegromail.pl",
            "no-reply@gls-pakete.de",
            "noreply@gls-group.nl",
            "noreply@gls.nl",
            "noreply@gls-france.fr",
            "no-reply@gls-france.fr",
        ],
        "subject": [
            "informacja o dostawie",
            "wurde durch GLS",
            "bezorgd",
            "afgeleverd",
            "votre colis a été livré",
            "livré par GLS",
        ],
        "body": [
            "została dzisiaj dostarczona",
            "Adresse erfolgreich zugestellt",
            "Am Wunschort abgestellt",
            "is bezorgd",
            "succesvol afgeleverd",
            "a bien été livré",
            "livraison effectuée",
        ],
    },
    "gls_delivering": {
        "email": [
            "noreply@gls-group.eu",
            "powiadomienia@allegromail.pl",
            "no-reply@gls-pakete.de",
            "noreply@gls-group.nl",
            "noreply@gls.nl",
            "noreply@gls-france.fr",
            "no-reply@gls-france.fr",
        ],
        "subject": [
            "paczka w drodze",
            "ist unterwegs",
            "kommt heute",
            "pakket onderweg",
            "bezorging vandaag",
            "votre colis est en cours de livraison",
            "GLS livre votre colis aujourd",
        ],
        "body": [
            "Zespół GLS",
            "GLS-Team",
            "fast da",
            "wordt vandaag bezorgd",
            "Uw pakket wordt vandaag",
            "en cours de livraison",
            "votre livreur GLS",
        ],
    },
    "gls_packages": {},
    "gls_tracking": {
        # https://gls-group.eu/GROUP/en/parcel-tracking?match=51687952111
        # https://gls-rtt.com/#/DE/de/95368751054
        "pattern": ["\\d{11,12}"],
    },
    # Australia Post
    "auspost_delivered": {
        "email": ["noreply@notifications.auspost.com.au"],
        "subject": ["Your shipment has been delivered"],
    },
    "auspost_delivering": {
        "email": ["noreply@notifications.auspost.com.au"],
        "subject": ["is on its way", "is coming today"],
    },
    "auspost_packages": {},
    "auspost_tracking": {"pattern": ["\\d{7,10,12}|[A-Za-z]{2}[0-9]{9}AU "]},
    # Evri
    "evri_delivered": {
        "email": ["do-not-reply@evri.com"],
        "subject": ["successfully delivered"],
    },
    "evri_delivering": {
        "email": ["do-not-reply@evri.com"],
        "subject": ["is now with your local Evri courier for delivery"],
    },
    "evri_packages": {},
    "evri_tracking": {"pattern": ["H[0-9A-Z]{15}"]},
    # DHL Parcel NL
    "dhl_parcel_nl_delivered": {
        "email": ["noreply@dhlparcel.nl"],
        "subject": ["Je pakket is bezorgd"],
    },
    "dhl_parcel_nl_delivering": {
        "email": ["noreply@dhlparcel.nl"],
        "subject": ["We staan vandaag", "We staan vanavond"],
    },
    "dhl_parcel_nl_packages": {},
    "dhl_parcel_nl_tracking": {"pattern": ["[0-9A-Z]{12,24}"]},
    # Bonshaw Distribution Network
    "bonshaw_distribution_network_delivered": {
        "email": ["parcel_tracking@bonshawdelivery.com"],
        "subject": ["Parcel Delivered! Commande Livrée!"],
    },
    "bonshaw_distribution_network_delivering": {
        "email": ["parcel_tracking@bonshawdelivery.com"],
        "subject": ["Parcel Out for Delivery! En attente de livraison!"],
    },
    "bonshaw_distribution_network_packages": {
        "email": ["parcel_tracking@bonshawdelivery.com"],
        "subject": ["Your package has been received!"],
    },
    "bonshaw_distribution_network_tracking": {"pattern": ["BNI[0-9]{9}"]},
    # Purolator
    "purolator_delivered": {
        "email": ["NotificationService@purolator.com"],
        "subject": ["Purolator - Your shipment is delivered"],
    },
    "purolator_delivering": {
        "email": ["NotificationService@purolator.com"],
        "subject": ["Purolator - Your shipment is out for delivery"],
    },
    "purolator_packages": {
        "email": ["NotificationService@purolator.com"],
        "subject": ["Purolator - Your shipment has been picked up"],
    },
    "purolator_tracking": {"pattern": ["\\d{12,15}"]},
    # Intelcom
    "intelcom_delivered": {
        "email": [
            "notifications@intelcom.ca",
            "notifications@dragonflyshipping.ca",
            "notifications@dragonflyshipping.com",
            "notifications@nl.dragonflyinternational.com",
        ],
        "subject": [
            "Your order has been delivered!",
            "Your package has been delivered",
            "Hooray! Your package is here",
            "Votre commande a été livrée!",
            "Votre colis a été livré!",
            "We hebben je pakket bezorgd!",
        ],
    },
    "intelcom_delivering": {
        "email": [
            "notifications@intelcom.ca",
            "notifications@dragonflyshipping.ca",
            "notifications@dragonflyshipping.com",
            "notifications@nl.dragonflyinternational.com",
        ],
        "subject": [
            "Your package is on the way!",
            "Your package is on its way",
            "Votre colis est en chemin!",
            "package is on its way",
            "Vandaag bezorgen we je pakket",
        ],
    },
    "intelcom_packages": {
        "email": [
            "notifications@intelcom.ca",
            "notifications@dragonflyshipping.ca",
            "notifications@dragonflyshipping.com",
            "notifications@nl.dragonflyinternational.com",
        ],
        "subject": [
            "Your package has been received!",
            "We've received your package",
            "We've received your",
            "Je pakket is bij ons aangekomen",
        ],
    },
    "intelcom_tracking": {"pattern": ["(NSPRSO[0-9]{10}|AMZNL[0-9]{12})"]},
    # Walmart
    "walmart_delivering": {
        "email": ["help@walmart.com"],
        "subject": [
            "Out for delivery",
            "Your package should arrive by",
            "Your delivery should arrive by",
        ],
    },
    "walmart_delivered": {
        "email": ["help@walmart.com"],
        "subject": [
            "Your order was delivered",
            "Some of your items were delivered",
            "Delivered:",
            "Arrived:",
        ],
    },
    "walmart_packages": {
        "email": ["help@walmart.com"],
        "subject": ["Thanks for your delivery order"],
    },
    "walmart_exception": {
        "email": ["help@walmart.com"],
        "subject": ["delivery is delayed"],
    },
    "walmart_tracking": {"pattern": [r"\b#?[0-9]{7}-[0-9]{7,8}\b"]},
    # BuildingLink
    "buildinglink_delivered": {
        "email": ["notify@buildinglink.com"],
        "subject": [
            "Your Amazon order has arrived",
            "delivery has arrived",
            "You have a package delivery",
            "You have a delivery at the front desk",
            "You have a DHL delivery",
            "You have an envelope",
        ],
    },
    "buildinglink_tracking": {},
    # Post NL
    "post_nl_delivering": {
        "email": [
            "noreply@notificatie.postnl.nl",
            "noreply@postnl.nl",
            "info@postnl.nl",
            "noreply@mypostnl.nl",
            "noreply@post.nl",
        ],
        "subject": [
            "Je pakket is onderweg",
            "De chauffer is onderweg",
            "onderweg",
            "wordt bezorgd",
            "bezorging vandaag",
            "verwacht tussen",
            "bezorger onderweg",
            "vandaag bezorgd",
        ],
        "body": [
            "onderweg naar",
            "wordt vandaag bezorgd",
            "verwacht tussen",
            "bezorger onderweg",
        ],
    },
    "post_nl_exception": {
        "email": ["noreply@notificatie.postnl.nl"],
        "subject": ["We hebben je gemist"],
    },
    "post_nl_delivered": {
        "email": [
            "noreply@notificatie.postnl.nl",
            "noreply@postnl.nl",
            "info@postnl.nl",
            "noreply@mypostnl.nl",
            "noreply@post.nl",
        ],
        "subject": [
            "Je pakket is bezorgd",
            "afgeleverd",
            "is bezorgd",
            "pakket bezorgd",
            "delivered",
            "succesvol bezorgd",
        ],
    },
    "post_nl_packages": {},
    "post_nl_tracking": {"pattern": ["3S[A-Z0-9]{10,18}"]},
    # Post DE
    "post_de_delivering": {
        "email": [
            "ankuendigung@brief.deutschepost.de",
        ],
        "subject": [
            "Ein Brief kommt in Kürze bei Ihnen an",
            "Ein Brief ist unterwegs zu Ihnen",
        ],
    },
    "post_de_delivered": {},
    "post_de_packages": {},
    "post_de_tracking": {},
    # Post Austria
    "post_at_delivering": {
        "email": ["MeineSendung@post.at"],
        "subject": ["Sendung ist in Zustellung"],
    },
    "post_at_exception": {},
    "post_at_delivered": {
        "email": ["MeineSendung@post.at"],
        "subject": ["Ihre Sendung wurde Zugestellt"],
    },
    "post_at_packages": {},
    "post_at_tracking": {"pattern": ["[0-9]{22}"]},
    # Rewe Lieferservice
    "rewe_lieferservice_delivering": {
        "email": ["reweshop@mailing.rewe.de"],
        "subject": ["Lieferschein zu deiner Bestellung beim REWE Lieferservice"],
        "body": ["Deine Lieferinformationen"],
    },
    "rewe_lieferservice_exception": {},
    "rewe_lieferservice_delivered": {
        "email": ["reweshop@mailing.rewe.de"],
        "subject": ["Deine Rechnung zu"],
        "body": ["Im Anhang dieser E-Mail kommt"],
    },
    # DPD Netherlands
    "dpd_nl_delivered": {
        "email": [
            "noreply@dpd.nl",
            "noreply@dpd.com",
            "noreply@dpdgroup.nl",
        ],
        "subject": ["bezorgd", "afgeleverd", "delivered"],
    },
    "dpd_nl_delivering": {
        "email": [
            "noreply@dpd.nl",
            "noreply@dpd.com",
            "noreply@dpdgroup.nl",
        ],
        "subject": [
            "pakket onderweg",
            "bezorging vandaag",
            "wordt vandaag bezorgd",
            "onderweg naar jou",
        ],
        "body": [
            "bezorger onderweg",
            "wordt vandaag bezorgd",
            "onze bezorger komt",
        ],
    },
    "dpd_nl_packages": {},
    "dpd_nl_tracking": {"pattern": ["\\d{14}"]},
    # bol.com (Netherlands)
    "bolcom_delivered": {
        "email": [
            "noreply@bol.com",
            "service@bol.com",
        ],
        "subject": ["bezorgd", "afgeleverd", "delivered"],
    },
    "bolcom_delivering": {
        "email": [
            "noreply@bol.com",
            "service@bol.com",
        ],
        "subject": [
            "verzonden",
            "onderweg",
            "wordt bezorgd",
            "meegegeven met",
        ],
        "body": [
            "nu bij PostNL",
            "nu bij DHL",
            "meegegeven met",
            "bezorger onderweg",
        ],
    },
    "bolcom_packages": {},
    "bolcom_tracking": {"pattern": ["3S[A-Z0-9]{10,18}", "JJD\\d{14,25}", "\\d{14}"]},
}

# Sensor definitions
SENSOR_TYPES: Final[dict[str, SensorEntityDescription]] = {
    "mail_updated": SensorEntityDescription(
        name="Mail Updated",
        icon="mdi:update",
        key="mail_updated",
        entity_category=EntityCategory.DIAGNOSTIC,
        device_class=SensorDeviceClass.TIMESTAMP,
    ),
    # USPS
    "usps_mail": SensorEntityDescription(
        name="Mail USPS Mail",
        native_unit_of_measurement="piece(s)",
        icon="mdi:mailbox-up",
        key="usps_mail",
    ),
    "usps_delivered": SensorEntityDescription(
        name="Mail USPS Delivered",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="usps_delivered",
    ),
    "usps_delivering": SensorEntityDescription(
        name="Mail USPS Delivering",
        native_unit_of_measurement="package(s)",
        icon="mdi:truck-delivery",
        key="usps_delivering",
    ),
    "usps_exception": SensorEntityDescription(
        name="Mail USPS Exception",
        native_unit_of_measurement="package(s)",
        icon="mdi:archive-alert",
        key="usps_exception",
    ),
    "usps_packages": SensorEntityDescription(
        name="Mail USPS Packages",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="usps_packages",
    ),
    # UPS
    "ups_delivered": SensorEntityDescription(
        name="Mail UPS Delivered",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="ups_delivered",
    ),
    "ups_delivering": SensorEntityDescription(
        name="Mail UPS Delivering",
        native_unit_of_measurement="package(s)",
        icon="mdi:truck-delivery",
        key="ups_delivering",
    ),
    "ups_exception": SensorEntityDescription(
        name="Mail UPS Exception",
        native_unit_of_measurement="package(s)",
        icon="mdi:archive-alert",
        key="ups_exception",
    ),
    "ups_packages": SensorEntityDescription(
        name="Mail UPS Packages",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="ups_packages",
    ),
    # FedEx
    "fedex_delivered": SensorEntityDescription(
        name="Mail FedEx Delivered",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="fedex_delivered",
    ),
    "fedex_delivering": SensorEntityDescription(
        name="Mail FedEx Delivering",
        native_unit_of_measurement="package(s)",
        icon="mdi:truck-delivery",
        key="fedex_delivering",
    ),
    "fedex_packages": SensorEntityDescription(
        name="Mail FedEx Packages",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="fedex_packages",
    ),
    "fedex_exception": SensorEntityDescription(
        name="Mail FedEx Exception",
        native_unit_of_measurement="package(s)",
        icon="mdi:archive-alert",
        key="fedex_exception",
    ),
    # Amazon
    "amazon_packages": SensorEntityDescription(
        name="Mail Amazon Packages",
        native_unit_of_measurement="package(s)",
        icon="mdi:package",
        key="amazon_packages",
    ),
    "amazon_delivered": SensorEntityDescription(
        name="Mail Amazon Packages Delivered",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="amazon_delivered",
    ),
    "amazon_exception": SensorEntityDescription(
        name="Mail Amazon Exception",
        native_unit_of_measurement="package(s)",
        icon="mdi:archive-alert",
        key="amazon_exception",
    ),
    "amazon_hub": SensorEntityDescription(
        name="Mail Amazon Hub Packages",
        native_unit_of_measurement="package(s)",
        icon="mdi:package",
        key="amazon_hub",
    ),
    "amazon_otp": SensorEntityDescription(
        name="Mail Amazon OTP Code",
        icon="mdi:counter",
        key="amazon_otp",
    ),
    # Canada Post
    "capost_delivered": SensorEntityDescription(
        name="Mail Canada Post Delivered",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="capost_delivered",
    ),
    "capost_delivering": SensorEntityDescription(
        name="Mail Canada Post Delivering",
        native_unit_of_measurement="package(s)",
        icon="mdi:truck-delivery",
        key="capost_delivering",
    ),
    "capost_mail": SensorEntityDescription(
        name="Mail Canada Post Mail",
        native_unit_of_measurement="piece(s)",
        icon="mdi:mailbox-up",
        key="capost_mail",
    ),
    "capost_packages": SensorEntityDescription(
        name="Mail Canada Post Packages",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="capost_packages",
    ),
    # DHL
    "dhl_delivered": SensorEntityDescription(
        name="Mail DHL Delivered",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="dhl_delivered",
    ),
    "dhl_delivering": SensorEntityDescription(
        name="Mail DHL Delivering",
        native_unit_of_measurement="package(s)",
        icon="mdi:truck-delivery",
        key="dhl_delivering",
    ),
    "dhl_packages": SensorEntityDescription(
        name="Mail DHL Packages",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="dhl_packages",
    ),
    # Hermes
    "hermes_delivered": SensorEntityDescription(
        name="Mail Hermes Delivered",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="hermes_delivered",
    ),
    "hermes_delivering": SensorEntityDescription(
        name="Mail Hermes Delivering",
        native_unit_of_measurement="package(s)",
        icon="mdi:truck-delivery",
        key="hermes_delivering",
    ),
    "hermes_packages": SensorEntityDescription(
        name="Mail Hermes Packages",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="hermes_packages",
    ),
    # Royal Mail
    "royal_delivered": SensorEntityDescription(
        name="Mail Royal Mail Delivered",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="royal_delivered",
    ),
    "royal_delivering": SensorEntityDescription(
        name="Mail Royal Mail Delivering",
        native_unit_of_measurement="package(s)",
        icon="mdi:truck-delivery",
        key="royal_delivering",
    ),
    "royal_packages": SensorEntityDescription(
        name="Mail Royal Mail Packages",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="royal_packages",
    ),
    # Australia Post
    "auspost_delivered": SensorEntityDescription(
        name="Mail AusPost Delivered",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant",
        key="auspost_delivered",
    ),
    "auspost_delivering": SensorEntityDescription(
        name="Mail AusPost Delivering",
        native_unit_of_measurement="package(s)",
        icon="mdi:truck-delivery",
        key="auspost_delivering",
    ),
    "auspost_packages": SensorEntityDescription(
        name="Mail AusPost Packages",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="auspost_packages",
    ),
    # Poczta Polska SA
    # "poczta_polska_delivered": SensorEntityDescription(
    #     name="Poczta Polska Delivered",
    #     native_unit_of_measurement="package(s)",
    #     icon="mdi:package-variant",
    #     key="poczta_polska_delivered",
    # ),
    "poczta_polska_delivering": SensorEntityDescription(
        name="Mail Poczta Polska Delivering",
        native_unit_of_measurement="package(s)",
        icon="mdi:truck-delivery",
        key="poczta_polska_delivering",
    ),
    "poczta_polska_packages": SensorEntityDescription(
        name="Mail Poczta Polska Packages",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="poczta_polska_packages",
    ),
    # InPost.pl
    "inpost_pl_delivering": SensorEntityDescription(
        name="Mail InPost.pl Delivering",
        native_unit_of_measurement="package(s)",
        icon="mdi:truck-delivery",
        key="inpost_pl_delivering",
    ),
    "inpost_pl_delivered": SensorEntityDescription(
        name="Mail InPost.pl Delivered",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant",
        key="inpost_pl_delivered",
    ),
    "inpost_pl_packages": SensorEntityDescription(
        name="Mail InPost.pl Packages",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="inpost_pl_packages",
    ),
    # DPD Poland
    "dpd_com_pl_delivering": SensorEntityDescription(
        name="Mail DPD.com.pl Delivering",
        native_unit_of_measurement="package(s)",
        icon="mdi:truck-delivery",
        key="dpd_com_pl_delivering",
    ),
    "dpd_com_pl_delivered": SensorEntityDescription(
        name="Mail DPD.com.pl Delivered",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant",
        key="dpd_com_pl_delivered",
    ),
    "dpd_com_pl_packages": SensorEntityDescription(
        name="Mail DPD.com.pl Packages",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="dpd_com_pl_packages",
    ),
    # DPD
    "dpd_delivering": SensorEntityDescription(
        name="Mail DPD Delivering",
        native_unit_of_measurement="package(s)",
        icon="mdi:truck-delivery",
        key="dpd_delivering",
    ),
    "dpd_delivered": SensorEntityDescription(
        name="Mail DPD Delivered",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant",
        key="dpd_delivered",
    ),
    "dpd_packages": SensorEntityDescription(
        name="Mail DPD Packages",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="dpd_packages",
    ),
    # DPD France
    "dpd_fr_delivering": SensorEntityDescription(
        name="Mail DPD FR Delivering",
        native_unit_of_measurement="package(s)",
        icon="mdi:truck-delivery",
        key="dpd_fr_delivering",
    ),
    "dpd_fr_delivered": SensorEntityDescription(
        name="Mail DPD FR Delivered",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant",
        key="dpd_fr_delivered",
    ),
    "dpd_fr_packages": SensorEntityDescription(
        name="Mail DPD FR Packages",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="dpd_fr_packages",
    ),
    # DPD UK
    "dpd_uk_delivering": SensorEntityDescription(
        name="Mail DPD UK Delivering",
        native_unit_of_measurement="package(s)",
        icon="mdi:truck-delivery",
        key="dpd_uk_delivering",
    ),
    "dpd_uk_delivered": SensorEntityDescription(
        name="Mail DPD UK Delivered",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant",
        key="dpd_uk_delivered",
    ),
    "dpd_uk_packages": SensorEntityDescription(
        name="Mail DPD UK Packages",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="dpd_uk_packages",
    ),
    # GLS
    "gls_delivering": SensorEntityDescription(
        name="Mail GLS Delivering",
        native_unit_of_measurement="package(s)",
        icon="mdi:truck-delivery",
        key="gls_delivering",
    ),
    "gls_delivered": SensorEntityDescription(
        name="Mail GLS Delivered",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant",
        key="gls_delivered",
    ),
    "gls_packages": SensorEntityDescription(
        name="Mail GLS Packages",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="gls_packages",
    ),
    # Evri
    "evri_delivered": SensorEntityDescription(
        name="Mail Evri Delivered",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="evri_delivered",
    ),
    "evri_delivering": SensorEntityDescription(
        name="Mail Evri Delivering",
        native_unit_of_measurement="package(s)",
        icon="mdi:truck-delivery",
        key="evri_delivering",
    ),
    "evri_packages": SensorEntityDescription(
        name="Mail Evri Packages",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="evri_packages",
    ),
    # DHL Parcel NL
    "dhl_parcel_nl_delivering": SensorEntityDescription(
        name="DHL Parcel NL Delivering",
        native_unit_of_measurement="package(s)",
        icon="mdi:truck-delivery",
        key="dhl_parcel_nl_delivering",
    ),
    "dhl_parcel_nl_delivered": SensorEntityDescription(
        name="DHL Parcel NL Delivered",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant",
        key="dhl_parcel_nl_delivered",
    ),
    "dhl_parcel_nl_packages": SensorEntityDescription(
        name="DHL Parcel NL Packages",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="dhl_parcel_nl_packages",
    ),
    # Bonshaw Distribution Network
    "bonshaw_distribution_network_delivered": SensorEntityDescription(
        name="Mail Bonshaw Distribution Network Delivered",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant",
        key="bonshaw_distribution_network_delivered",
    ),
    "bonshaw_distribution_network_delivering": SensorEntityDescription(
        name="Mail Bonshaw Distribution Network Delivering",
        native_unit_of_measurement="package(s)",
        icon="mdi:truck-delivery",
        key="bonshaw_distribution_network_delivering",
    ),
    "bonshaw_distribution_network_packages": SensorEntityDescription(
        name="Mail Bonshaw Distribution Network Packages",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="bonshaw_distribution_network_packages",
    ),
    # Purolator
    "purolator_delivered": SensorEntityDescription(
        name="Mail Purolator Delivered",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant",
        key="purolator_delivered",
    ),
    "purolator_delivering": SensorEntityDescription(
        name="Mail Purolator Delivering",
        native_unit_of_measurement="package(s)",
        icon="mdi:truck-delivery",
        key="purolator_delivering",
    ),
    "purolator_packages": SensorEntityDescription(
        name="Mail Purolator Packages",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="purolator_packages",
    ),
    # Intelcom
    "intelcom_delivered": SensorEntityDescription(
        name="Mail Intelcom Delivered",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant",
        key="intelcom_delivered",
    ),
    "intelcom_delivering": SensorEntityDescription(
        name="Mail Intelcom Delivering",
        native_unit_of_measurement="package(s)",
        icon="mdi:truck-delivery",
        key="intelcom_delivering",
    ),
    "intelcom_packages": SensorEntityDescription(
        name="Mail Intelcom Packages",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="intelcom_packages",
    ),
    # Walmart
    "walmart_delivering": SensorEntityDescription(
        name="Mail Walmart Delivering",
        native_unit_of_measurement="package(s)",
        icon="mdi:truck-delivery",
        key="walmart_delivering",
    ),
    "walmart_delivered": SensorEntityDescription(
        name="Mail Walmart Delivered",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="walmart_delivered",
    ),
    "walmart_packages": SensorEntityDescription(
        name="Mail Walmart Packages",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="walmart_packages",
    ),
    "walmart_exception": SensorEntityDescription(
        name="Mail Walmart Exception",
        native_unit_of_measurement="package(s)",
        icon="mdi:archive-alert",
        key="walmart_exception",
    ),
    # BuildingLink
    "buildinglink_delivered": SensorEntityDescription(
        name="Mail BuildingLink Delivered",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="buildinglink_delivered",
    ),
    # Post NL
    "post_nl_delivering": SensorEntityDescription(
        name="Post NL Delivering",
        native_unit_of_measurement="package(s)",
        icon="mdi:truck-delivery",
        key="post_nl_delivering",
    ),
    "post_nl_exception": SensorEntityDescription(
        name="Post NL Missed Delivery",
        native_unit_of_measurement="package(s)",
        icon="mdi:truck-alert",
        key="post_nl_exception",
    ),
    "post_nl_delivered": SensorEntityDescription(
        name="Post NL Delivered",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant",
        key="post_nl_delivered",
    ),
    "post_nl_packages": SensorEntityDescription(
        name="Post NL Packages",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="post_nl_packages",
    ),
    # Post DE
    "post_de_delivering": SensorEntityDescription(
        name="Post DE Delivering",
        native_unit_of_measurement="package(s)",
        icon="mdi:truck-delivery",
        key="post_de_delivering",
    ),
    # "post_de_delivered": SensorEntityDescription(
    #    name="Post DE Delivered",
    #    native_unit_of_measurement="package(s)",
    #    icon="mdi:truck-delivery",
    #    key="post_de_delivered",
    # ),
    "post_de_packages": SensorEntityDescription(
        name="Post DE Packages",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="post_de_packages",
    ),
    # Post Austria
    "post_at_delivering": SensorEntityDescription(
        name="Post AT Delivering",
        native_unit_of_measurement="package(s)",
        icon="mdi:truck-delivery",
        key="post_at_delivering",
    ),
    "post_at_delivered": SensorEntityDescription(
        name="Post AT Delivered",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant",
        key="post_at_delivered",
    ),
    "post_at_packages": SensorEntityDescription(
        name="Post AT Packages",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="post_at_packages",
    ),
    # Rewe Lieferservice
    "rewe_lieferservice_delivering": SensorEntityDescription(
        name="Rewe Lieferservice Delivering",
        native_unit_of_measurement="package(s)",
        icon="mdi:truck-delivery",
        key="rewe_lieferservice_delivering",
    ),
    "rewe_lieferservice_delivered": SensorEntityDescription(
        name="Rewe Lieferservice Delivered",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant",
        key="rewe_lieferservice_delivered",
    ),
    "rewe_lieferservice_packages": SensorEntityDescription(
        name="Rewe Lieferservice Packages",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="rewe_lieferservice_packages",
    ),
    # DPD Netherlands
    "dpd_nl_delivering": SensorEntityDescription(
        name="Mail DPD NL Delivering",
        native_unit_of_measurement="package(s)",
        icon="mdi:truck-delivery",
        key="dpd_nl_delivering",
    ),
    "dpd_nl_delivered": SensorEntityDescription(
        name="Mail DPD NL Delivered",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant",
        key="dpd_nl_delivered",
    ),
    "dpd_nl_packages": SensorEntityDescription(
        name="Mail DPD NL Packages",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="dpd_nl_packages",
    ),
    # bol.com (Netherlands)
    "bolcom_delivering": SensorEntityDescription(
        name="Mail bol.com Delivering",
        native_unit_of_measurement="package(s)",
        icon="mdi:truck-delivery",
        key="bolcom_delivering",
    ),
    "bolcom_delivered": SensorEntityDescription(
        name="Mail bol.com Delivered",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant",
        key="bolcom_delivered",
    ),
    "bolcom_packages": SensorEntityDescription(
        name="Mail bol.com Packages",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant-closed",
        key="bolcom_packages",
    ),
    # DHL Letter Preview
    "dhl_brief_anzahl": SensorEntityDescription(
        name="DHL Letter Preview",
        native_unit_of_measurement="piece(s)",
        icon="mdi:email-open",
        key="dhl_brief_anzahl",
    ),
    "dhl_brief_naechster": SensorEntityDescription(
        name="DHL Letter Next Delivery",
        icon="mdi:calendar",
        key="dhl_brief_naechster",
        device_class=SensorDeviceClass.DATE,
    ),
    ###
    # !!! Insert new sensors above these two !!!
    ###
    "zpackages_delivered": SensorEntityDescription(
        name="Mail Packages Delivered",
        native_unit_of_measurement="package(s)",
        icon="mdi:package-variant",
        key="zpackages_delivered",
    ),
    "zpackages_transit": SensorEntityDescription(
        name="Mail Packages In Transit",
        native_unit_of_measurement="package(s)",
        icon="mdi:truck-delivery",
        key="zpackages_transit",
    ),
    # Universal tracking scanner
    "universal_packages": SensorEntityDescription(
        name="Mail Universal Packages",
        native_unit_of_measurement="package(s)",
        icon="mdi:text-search",
        key="universal_packages",
    ),
}

BINARY_SENSORS: Final[dict[str, MailandPackagesBinarySensorEntityDescription]] = {
    "usps_update": MailandPackagesBinarySensorEntityDescription(
        name="USPS Image Updated",
        key="usps_update",
        device_class=BinarySensorDeviceClass.UPDATE,
        selectable=False,
        entity_registry_enabled_default=False,
    ),
    "amazon_update": MailandPackagesBinarySensorEntityDescription(
        name="Amazon Image Updated",
        key="amazon_update",
        device_class=BinarySensorDeviceClass.UPDATE,
        selectable=False,
        entity_registry_enabled_default=False,
    ),
    "usps_mail_delivered": MailandPackagesBinarySensorEntityDescription(
        name="USPS Mail Delivered",
        key="usps_mail_delivered",
        entity_registry_enabled_default=False,
        selectable=True,
    ),
}


IMAGE_SENSORS: Final[dict[str, SensorEntityDescription]] = {
    "usps_mail_image_system_path": SensorEntityDescription(
        name="Mail Image System Path",
        icon="mdi:folder-multiple-image",
        key="usps_mail_image_system_path",
        entity_category=EntityCategory.DIAGNOSTIC,
    ),
    "usps_mail_image_url": SensorEntityDescription(
        name="Mail Image URL",
        icon="mdi:link-variant",
        key="usps_mail_image_url",
        entity_category=EntityCategory.DIAGNOSTIC,
    ),
    "usps_mail_grid_image_path": SensorEntityDescription(
        name="Mail Grid Image Path",
        icon="mdi:folder-multiple-image",
        key="usps_mail_grid_image_path",
        entity_category=EntityCategory.DIAGNOSTIC,
        entity_registry_enabled_default=False,
    ),
}

# Name
CAMERA_DATA = {
    "usps_camera": ["Mail USPS Camera"],
    "ups_camera": ["Mail UPS Camera"],
    "amazon_camera": ["Mail Amazon Delivery Camera"],
    "walmart_camera": ["Mail Walmart Delivery Camera"],
    "fedex_camera": ["Mail FedEx Delivery Camera"],
    "generic_camera": ["Mail Generic Delivery Camera"],
}

# Configuration for shipper-specific image extraction parameters
# Only contains values that cannot be derived from shipper_name
CAMERA_EXTRACTION_CONFIG = {
    "ups": {
        "image_type": "jpeg",
        "cid_name": "deliveryPhoto",
    },
    "walmart": {
        "image_type": "png",
        "cid_name": "deliveryProofLabel",
    },
    "fedex": {
        "image_type": "jpeg",
        "attachment_filename_pattern": "delivery",
    },
}

# Sensor Index
SENSOR_NAME = 0
SENSOR_UNIT = 1
SENSOR_ICON = 2

# For sensors with delivering and delivered statuses
SHIPPERS = [
    "amazon",
    "capost",
    "dhl",
    "fedex",
    "ups",
    "usps",
    "walmart",
    "hermes",
    "royal",
    "auspost",
    "inpost_pl",
    "dpd_com_pl",
    "dpd",
    "gls",
    "dhl_parcel_nl",
    "bonshaw_distribution_network",
    "purolator",
    "intelcom",
    "post_nl",
    "post_at",
    "rewe_lieferservice",
    "dpd_nl",
    "dpd_fr",
    "dpd_uk",
    "bolcom",
    "poczta_polska",
    "buildinglink",
    "post_de",
]

# Authentication types
CONF_AUTH_TYPE = "auth_type"
AUTH_TYPE_PASSWORD = "password"
AUTH_TYPE_OAUTH_MICROSOFT = "oauth2_microsoft"
AUTH_TYPE_OAUTH_GOOGLE = "oauth2_google"
AUTH_TYPES = [AUTH_TYPE_PASSWORD, AUTH_TYPE_OAUTH_MICROSOFT, AUTH_TYPE_OAUTH_GOOGLE]

# OAuth2 scopes per provider
OAUTH_SCOPES = {
    AUTH_TYPE_OAUTH_MICROSOFT: "https://outlook.office.com/IMAP.AccessAsUser.All offline_access",
    AUTH_TYPE_OAUTH_GOOGLE: "https://mail.google.com/",
}

# OAuth2 provider IMAP defaults
OAUTH_IMAP_DEFAULTS = {
    AUTH_TYPE_OAUTH_MICROSOFT: {
        "host": "outlook.office365.com",
        "port": 993,
        "imap_security": "SSL",
    },
    AUTH_TYPE_OAUTH_GOOGLE: {
        "host": "imap.gmail.com",
        "port": 993,
        "imap_security": "SSL",
    },
}
